#ifndef BYONDAPI_WRAPPERS_H
#define BYONDAPI_WRAPPERS_H

#include "byondapi.h"

/*
	C++ wrapper classes
 */

class ByondExtException {
	char *str;
	public:
	ByondExtException();
	ByondExtException(char const *msg);
	ByondExtException(ByondExtException const &other);
	~ByondExtException();
	ByondExtException& operator=(ByondExtException const &other);
	char const *ToString();
};

/*
	ByondValue is a wrapper class for CByondValue that takes care of the init,
	free, and assignment stuff for you.

	Because byondapi is limited to C structures, you can't return a ByondValue
	directly from your function. Instead, you need to call Detach(). Example:

	extern "C" BYOND_EXPORT CByondValue MyFunction(int n, ByondValue args[]) {
		ByondValue return_value;
		...	// function body
		return return_value.Detach();
	}

	The Detach() call returns a copy of the internal CByondValue while clearing
	out the ByondValue so it has nothing to clean up. The CByondValue copy
	still has to be cleaned up, which the caller (BYOND itself) will take care of
	on return.

	The args[] array is declared as ByondValue instead of CByondValue because
	it doesn't affect the call and makes the arguments easier to work wtih.
 */

class ByondValue: public CByondValue {
	public:
	ByondValue();
	~ByondValue();
	ByondValue(ByondValueType type, u4c ref);
	ByondValue(float f);
	ByondValue(char const *str);
	ByondValue(CByondValue const &src);
	explicit ByondValue(ByondValue const &src);
#ifdef _SUPPORT_MOVES
	ByondValue(CByondValue &&src);
	explicit ByondValue(ByondValue &&src);
#endif

	// returns a dumb C struct while freeing this class, so you can return ByondValue(...).Detach() from a function
	CByondValue Detach();

	ByondValue &operator=(float f);
	ByondValue &operator=(char const *str);
	ByondValue &operator=(CByondValue const &src);
#ifdef _SUPPORT_MOVES
	ByondValue &operator=(CByondValue &&src);
#endif
	bool operator==(CByondValue const &v) const;
	bool operator!=(CByondValue const &v) const;

	void Clear();
	ByondValueType GetType() const;

	bool IsNull() const;
	bool IsNum() const;
	bool IsStr() const;
	bool IsList() const;

	float GetNum() const;
	char const *GetStr() const;
	u4c GetRef() const;

	void SetNum(float f);
	bool SetStr(char const *str);
	void SetRef(ByondValueType type, u4c ref);

	ByondValue &Swap(CByondValue &other);

	ByondValue ToString() const;
};

class ByondValueList: public CByondValueList {
	public:
	ByondValueList();
	ByondValueList(ByondValue const *items, u4c count);
	ByondValueList(const CByondValueList &src);
#ifdef _SUPPORT_MOVES
	ByondValueList(CByondValueList &&src);
#endif
	~ByondValueList();

	ByondValueList& operator=(CByondValueList const &src);
#ifdef _SUPPORT_MOVES
	ByondValueList& operator=(CByondValueList &&src);
#endif

	u4c GetCount() const;
	u4c GetCapacity() const;

	void Clear();
	bool SetCount(u4c n);
	bool SetCapacity(u4c n);
	bool Add(ByondValue const &src);
	bool InsertAt(int idx, ByondValue const &src);
	bool Splice(int idx, u4c delete_count=0, ByondValue const *items=0, u4c insert_count=0);
	u4c RemoveAt(u4c idx, u4c n=1);

	// no bounds checking
	ByondValue &operator[](u4c idx);
	ByondValue const &operator[](u4c idx) const;
};


/*
	All of the C++-wrapped Byond_ functions throw ByondExtException on failure.
 */
ByondValue Byond_ReadVar(ByondValue const &loc, char const *varname);
ByondValue Byond_ReadVarByStrId(ByondValue const &loc, u4c varname);
void Byond_WriteVar(ByondValue const &loc, char const *varname, ByondValue val);
void Byond_WriteVarByStrId(ByondValue const &loc, u4c varname, ByondValue val);

ByondValue Byond_CreateList();
ByondValue Byond_CreateList(ByondValueList const &items);

ByondValueList Byond_ReadList(ByondValue const &loc);
void Byond_ReadList(ByondValue const &loc, ByondValueList &list);
void Byond_WriteList(ByondValue const &loc, ByondValueList const &list);

ByondValue Byond_ReadListIndex(ByondValue const &loc, ByondValue const &idx);
void Byond_WriteListIndex(ByondValue const &loc, ByondValue const &idx, ByondValue const &val);

ByondValue Byond_ReadPointer(ByondValue const &ptr);
void Byond_WritePointer(ByondValue const &ptr, ByondValue val);

ByondValue Byond_CallProc(ByondValue const &src, char const *name, CByondValue const *arg, u4c arg_count);
ByondValue Byond_CallProcByStrId(ByondValue const &src, u4c name, CByondValue const *arg, u4c arg_count);

ByondValue Byond_CallGlobalProc(char const *name, CByondValue const *arg, u4c arg_count);
ByondValue Byond_CallGlobalProcByStrId(u4c name, CByondValue const *arg, u4c arg_count);

ByondValue Byond_ToString(ByondValue const &src);

ByondValueList Byond_Block(CByondXYZ const &corner1, CByondXYZ const &corner2);
ByondValue Byond_Length(ByondValue const &src);
ByondValue Byond_Locate(ByondValue const &type);
ByondValue Byond_LocateIn(ByondValue const &type, ByondValue const &list);
ByondValue Byond_LocateXYZ(CByondXYZ const &xyz);
ByondValue Byond_New(ByondValue const &src, CByondValue const *arg, u4c arg_count);
ByondValue Byond_NewArglist(ByondValue const &src, ByondValue const &arglist);
ByondValue Byond_Refcount(ByondValue const &src);
CByondXYZ Byond_XYZ(ByondValue const &src);

#endif
