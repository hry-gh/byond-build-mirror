#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "byondapi_cpp_wrappers.h"

#if defined(WIN32) && defined(_MSC_VER)
#pragma warning(disable : 4996)	// disable bogus deprecation warning
#endif

/*
	C++ wrapper defs
 */
ByondExtException::ByondExtException() {str = NULL;}
ByondExtException::ByondExtException(char const *msg) {str = msg ? strdup(msg) : NULL;}
ByondExtException::ByondExtException(ByondExtException const &other) {
	str = other.str ? strdup(other.str) : NULL;
}
ByondExtException::~ByondExtException() {free(str);}
ByondExtException& ByondExtException::operator=(ByondExtException const &other) {
	if(this != &other) {
		free(str);
		str = other.str ? strdup(other.str) : NULL;
	}
	return *this;
}
char const *ByondExtException::ToString() {return str;}

ByondValue::ByondValue() {ByondValue_Init(this);}
ByondValue::~ByondValue() {ByondValue_Free(this);}
ByondValue::ByondValue(ByondValueType type, u4c ref) {ByondValue_InitRef(this,type,ref);}
ByondValue::ByondValue(float f) {ByondValue_InitNum(this,f);}
ByondValue::ByondValue(char const *str) {ByondValue_InitStr(this,str);}
ByondValue::ByondValue(CByondValue const &src) {ByondValue_Init(this); ByondValue_CopyFrom(this,&src);}
ByondValue::ByondValue(ByondValue const &src) {ByondValue_Init(this); ByondValue_CopyFrom(this,&src);}
#ifdef _SUPPORT_MOVES
ByondValue::ByondValue(CByondValue &&src) {*(CByondValue*)this = src; ByondValue_Init(&src);}
ByondValue::ByondValue(ByondValue &&src) {*(CByondValue*)this = src; ByondValue_Init(&src);}
#endif

CByondValue ByondValue::Detach() {
	CByondValue ret = *this;
	ByondValue_Init(this);
	return ret;
}

ByondValue &ByondValue::operator=(float f) {ByondValue_Free(this); ByondValue_InitNum(this,f); return *this;}
ByondValue &ByondValue::operator=(char const *str) {ByondValue_Free(this); ByondValue_InitStr(this,str); return *this;}
ByondValue &ByondValue::operator=(CByondValue const &src) {if(&src != this) ByondValue_CopyFrom(this,&src); return *this;}
#ifdef _SUPPORT_MOVES
ByondValue &ByondValue::operator=(CByondValue &&src) {if(&src != this) ByondValue_MoveFrom(this,&src); return *this;}
#endif
bool ByondValue::operator==(CByondValue const &v) const {return ByondValue_Equals(this, &v);}
bool ByondValue::operator!=(CByondValue const &v) const {return !ByondValue_Equals(this, &v);}

void ByondValue::Clear() {ByondValue_Free(this);}
ByondValueType ByondValue::GetType() const {return type;}

bool ByondValue::IsNull() const {return ByondValue_IsNull(this);}
bool ByondValue::IsNum() const {return ByondValue_IsNum(this);}
bool ByondValue::IsStr() const {return ByondValue_IsStr(this);}
bool ByondValue::IsList() const {return ByondValue_IsList(this);}

float ByondValue::GetNum() const {return ByondValue_GetNum(this);}
char const *ByondValue::GetStr() const {return ByondValue_GetStr(this);}
u4c ByondValue::GetRef() const {return ByondValue_GetRef(this);}

void ByondValue::SetNum(float f) {ByondValue_Free(this); return ByondValue_InitNum(this,f);}
bool ByondValue::SetStr(char const *str) {ByondValue_Free(this); return ByondValue_InitStr(this,str);}
void ByondValue::SetRef(ByondValueType type, u4c ref) {ByondValue_Free(this); ByondValue_InitRef(this,type,ref);}

ByondValue &ByondValue::Swap(CByondValue &other) {
	CByondValue tmp = *this;
	*(CByondValue*)this = other;
	other = tmp;
	return *this;
}

ByondValue ByondValue::ToString() const {
	ByondValue result;
	Byond_ToString(this, &result);
	return result.Detach();
}


ByondValueList::ByondValueList() {ByondValueList_Init(this);}
ByondValueList::ByondValueList(ByondValue const *items, u4c count) {
	ByondValueList_Init(this);
	ByondValueList_Splice(this, 0, 0, items, count);
}
ByondValueList::ByondValueList(const CByondValueList &src) {
	ByondValueList_Init(this);
	ByondValueList_CopyFrom(this, &src);
}
#ifdef _SUPPORT_MOVES
ByondValueList::ByondValueList(CByondValueList &&src) {
	ByondValueList_Init(this);
	ByondValueList_MoveFrom(this, &src);
}
#endif
ByondValueList::~ByondValueList() {ByondValueList_Free(this);}

ByondValueList& ByondValueList::operator=(CByondValueList const &src) {if(this != &src) ByondValueList_CopyFrom(this,&src); return *this;}
#ifdef _SUPPORT_MOVES
ByondValueList& ByondValueList::operator=(CByondValueList &&src) {if(this != &src) ByondValueList_MoveFrom(this,&src); return *this;}
#endif

u4c ByondValueList::GetCount() const {return count;}
u4c ByondValueList::GetCapacity() const {return capacity;}

void ByondValueList::Clear() {ByondValueList_Free(this);}
bool ByondValueList::SetCount(u4c n) {return ByondValueList_SetCount(this, n);}
bool ByondValueList::SetCapacity(u4c n) {return ByondValueList_SetCapacity(this, n);}
bool ByondValueList::Add(ByondValue const &src) {return ByondValueList_Add(this, &src);}
bool ByondValueList::InsertAt(int idx, ByondValue const &src) {return ByondValueList_InsertAt(this, idx, &src);}
bool ByondValueList::Splice(int idx, u4c delete_count, ByondValue const *items, u4c insert_count) {return ByondValueList_Splice(this, idx, delete_count, items, insert_count);}
u4c ByondValueList::RemoveAt(u4c idx, u4c n) {return ByondValueList_RemoveAt(this, idx, n);}

// no bounds checking
ByondValue &ByondValueList::operator[](u4c idx) {return ((ByondValue *)items)[idx];}
ByondValue const &ByondValueList::operator[](u4c idx) const {return ((ByondValue const *)items)[idx];}


/*
	All of the C++-wrapped Byond_ functions throw ByondExtException on failure.
 */
ByondValue Byond_ReadVar(ByondValue const &loc, char const *varname) {
	ByondValue result;
	bool success = Byond_ReadVar(&loc, varname, &result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}
ByondValue Byond_ReadVarByStrId(ByondValue const &loc, u4c varname) {
	ByondValue result;
	bool success = Byond_ReadVarByStrId(&loc, varname, &result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}
void Byond_WriteVar(ByondValue const &loc, char const *varname, ByondValue val) {
	bool success = Byond_WriteVar(&loc, varname, &val);
	if(!success) throw ByondExtException(Byond_LastError());
}
void Byond_WriteVarByStrId(ByondValue const &loc, u4c varname, ByondValue val) {
	bool success = Byond_WriteVarByStrId(&loc, varname, &val);
	if(!success) throw ByondExtException(Byond_LastError());
}

ByondValueList Byond_ReadList(ByondValue const &loc) {
	ByondValueList result;
	bool success = Byond_ReadList(&loc, &result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}
void Byond_ReadList(ByondValue const &loc, ByondValueList &list) {
	bool success = Byond_ReadList(&loc, &list);
	if(!success) throw ByondExtException(Byond_LastError());
}
void Byond_WriteList(ByondValue const &loc, ByondValueList const &list) {
	bool success = Byond_WriteList(&loc, &list);
	if(!success) throw ByondExtException(Byond_LastError());
}

ByondValue Byond_ReadListIndex(ByondValue const &loc, ByondValue const &idx) {
	ByondValue result;
	bool success = Byond_ReadListIndex(&loc, &idx, &result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}
void Byond_WriteListIndex(ByondValue const &loc, ByondValue const &idx, ByondValue const &val) {
	bool success = Byond_WriteListIndex(&loc, &idx, &val);
	if(!success) throw ByondExtException(Byond_LastError());
}

ByondValue Byond_CreateList() {
	ByondValue result;
	bool success = Byond_CreateList(&result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}
ByondValue Byond_CreateList(ByondValueList const &items) {
	ByondValue result;
	bool success = Byond_CreateList(&result);
	if(!success) throw ByondExtException(Byond_LastError());
	success = Byond_WriteList(&result, &items);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

ByondValue Byond_ReadPointer(ByondValue const &ptr) {
	ByondValue result;
	bool success = Byond_ReadPointer(&ptr, &result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}
void Byond_WritePointer(ByondValue const &ptr, ByondValue val) {
	bool success = Byond_WritePointer(&ptr, &val);
	if(!success) throw ByondExtException(Byond_LastError());
}

ByondValue Byond_CallProc(ByondValue const &src, char const *name, CByondValue const *arg, u4c arg_count) {
	ByondValue result;
	bool success = Byond_CallProc(&src,name,arg,arg_count,&result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

ByondValue Byond_CallProcByStrId(ByondValue const &src, u4c name, CByondValue const *arg, u4c arg_count) {
	ByondValue result;
	bool success = Byond_CallProcByStrId(&src,name,arg,arg_count,&result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

ByondValue Byond_CallGlobalProc(char const *name, CByondValue const *arg, u4c arg_count) {
	ByondValue result;
	bool success = Byond_CallGlobalProc(name,arg,arg_count,&result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

ByondValue Byond_CallGlobalProcByStrId(u4c name, CByondValue const *arg, u4c arg_count) {
	ByondValue result;
	bool success = Byond_CallGlobalProcByStrId(name,arg,arg_count,&result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

ByondValue Byond_ToString(ByondValue const &src) {
	ByondValue result;
	bool success = Byond_ToString(&src,&result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

// builtins
ByondValueList Byond_Block(CByondXYZ const &corner1, CByondXYZ const &corner2) {
	ByondValueList result;
	bool success = Byond_Block(&corner1,&corner2,&result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

ByondValue Byond_Length(ByondValue const &src) {
	ByondValue result;
	bool success = Byond_Length(&src,&result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

ByondValue Byond_Locate(ByondValue const &type) {
	ByondValue result;
	bool success = Byond_LocateIn(&type, NULL, &result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

ByondValue Byond_LocateIn(ByondValue const &type, ByondValue const &list) {
	ByondValue result;
	bool success = Byond_LocateIn(&type, &list, &result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

ByondValue Byond_LocateXYZ(CByondXYZ const &xyz) {
	ByondValue result;
	Byond_LocateXYZ(&xyz, &result);	// return value is always true
	return result;
}

ByondValue Byond_New(ByondValue const &src, CByondValue const *arg, u4c arg_count) {
	ByondValue result;
	bool success = Byond_New(&src,arg,arg_count,&result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

ByondValue Byond_NewArglist(ByondValue const &src, ByondValue const &arglist) {
	ByondValue result;
	bool success = Byond_NewArglist(&src,&arglist,&result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

ByondValue Byond_Refcount(ByondValue const &src) {
	ByondValue result;
	bool success = Byond_Refcount(&src,&result);
	if(!success) throw ByondExtException(Byond_LastError());
	return result;
}

CByondXYZ Byond_XYZ(ByondValue const &src) {
	CByondXYZ xyz;
	bool success = Byond_XYZ(&src,&xyz);
	if(!success) throw ByondExtException(Byond_LastError());
	return xyz;
}
